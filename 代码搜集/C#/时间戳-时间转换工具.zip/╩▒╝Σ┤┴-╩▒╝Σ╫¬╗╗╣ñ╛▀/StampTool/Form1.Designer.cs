﻿namespace StampTool
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtStamp1 = new System.Windows.Forms.TextBox();
            this.txtNormal1 = new System.Windows.Forms.TextBox();
            this.txtStamp2 = new System.Windows.Forms.TextBox();
            this.btnStampToNormal = new System.Windows.Forms.Button();
            this.btnNomalToStamp = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // txtStamp1
            // 
            this.txtStamp1.Location = new System.Drawing.Point(23, 32);
            this.txtStamp1.Name = "txtStamp1";
            this.txtStamp1.Size = new System.Drawing.Size(154, 21);
            this.txtStamp1.TabIndex = 0;
            // 
            // txtNormal1
            // 
            this.txtNormal1.Location = new System.Drawing.Point(346, 30);
            this.txtNormal1.Name = "txtNormal1";
            this.txtNormal1.Size = new System.Drawing.Size(139, 21);
            this.txtNormal1.TabIndex = 1;
            // 
            // txtStamp2
            // 
            this.txtStamp2.Location = new System.Drawing.Point(346, 80);
            this.txtStamp2.Name = "txtStamp2";
            this.txtStamp2.Size = new System.Drawing.Size(139, 21);
            this.txtStamp2.TabIndex = 2;
            // 
            // btnStampToNormal
            // 
            this.btnStampToNormal.Location = new System.Drawing.Point(188, 30);
            this.btnStampToNormal.Name = "btnStampToNormal";
            this.btnStampToNormal.Size = new System.Drawing.Size(126, 23);
            this.btnStampToNormal.TabIndex = 3;
            this.btnStampToNormal.Text = "时间戳转普通时间";
            this.btnStampToNormal.UseVisualStyleBackColor = true;
            this.btnStampToNormal.Click += new System.EventHandler(this.btnStampToNormal_Click);
            // 
            // btnNomalToStamp
            // 
            this.btnNomalToStamp.Location = new System.Drawing.Point(188, 80);
            this.btnNomalToStamp.Name = "btnNomalToStamp";
            this.btnNomalToStamp.Size = new System.Drawing.Size(126, 23);
            this.btnNomalToStamp.TabIndex = 4;
            this.btnNomalToStamp.Text = "普通时间转时间戳";
            this.btnNomalToStamp.UseVisualStyleBackColor = true;
            this.btnNomalToStamp.Click += new System.EventHandler(this.btnNomalToStamp_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(23, 82);
            this.dateTimePicker1.MinDate = new System.DateTime(1970, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(154, 21);
            this.dateTimePicker1.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(512, 143);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.btnNomalToStamp);
            this.Controls.Add(this.btnStampToNormal);
            this.Controls.Add(this.txtStamp2);
            this.Controls.Add(this.txtNormal1);
            this.Controls.Add(this.txtStamp1);
            this.Name = "Form1";
            this.Text = "时间戳和普通时间格式的转换";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtStamp1;
        private System.Windows.Forms.TextBox txtNormal1;
        private System.Windows.Forms.TextBox txtStamp2;
        private System.Windows.Forms.Button btnStampToNormal;
        private System.Windows.Forms.Button btnNomalToStamp;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}

